import React, { useState } from 'react';
import DeviceList from './DeviceList';
import TabContent from './TabContent';

const MainContent = () => {
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('live');

  return (
    <div className="flex flex-col h-full">
      <div className="flex flex-1 overflow-hidden">
        <DeviceList 
          selectedDevice={selectedDevice}
          setSelectedDevice={setSelectedDevice}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
        />
        <TabContent 
          selectedDevice={selectedDevice}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />
      </div>
    </div>
  );
};

export default MainContent;