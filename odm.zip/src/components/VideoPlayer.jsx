import React from 'react';

const VideoPlayer = ({ device }) => {
  return (
    <div className="flex-1 bg-black rounded-lg overflow-hidden relative">
      <div className="absolute inset-0 flex items-center justify-center text-white">
        <div className="text-center">
          <p className="text-lg">Live stream from {device.address}</p>
          <p className="text-sm text-gray-400 mt-1">{device.name} - {device.location}</p>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;