import React from 'react';
import VideoPlayer from './VideoPlayer';
import PTZControls from './PTZControls';

const TabContent = ({ selectedDevice, activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'live', name: 'Live video' },
    { id: 'video', name: 'Video streaming' },
    { id: 'imaging', name: 'Imaging settings' },
    { id: 'analytics', name: 'Analytics' },
    { id: 'rules', name: 'Rules' },
    { id: 'ptz', name: 'PTZ control' },
    { id: 'profiles', name: 'Profiles' }
  ];

  return (
    <div className="flex-1 flex flex-col bg-white">
      {selectedDevice ? (
        <>
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  className={`px-4 py-3 text-sm font-medium ${activeTab === tab.id ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>
          
          <div className="flex-1 overflow-auto p-4">
            {activeTab === 'live' && (
              <div className="h-full flex flex-col">
                <VideoPlayer device={selectedDevice} />
                <PTZControls />
              </div>
            )}
            
            {activeTab === 'video' && (
              <div className="h-full flex items-center justify-center text-gray-500">
                Video streaming settings
              </div>
            )}
            
            {/* Add other tab contents here */}
          </div>
        </>
      ) : (
        <div className="h-full flex items-center justify-center text-gray-500">
          Please select a device from the list
        </div>
      )}
    </div>
  );
};

export default TabContent;