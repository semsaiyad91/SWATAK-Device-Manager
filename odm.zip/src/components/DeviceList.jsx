import React from 'react';
import DeviceCard from './DeviceCard';
import { ArrowPathIcon } from '@heroicons/react/24/outline';

const mockDevices = [
  {
    id: 1,
    name: 'Securus',
    firmware: 'V5.00.R02.844309ED.10010.34',
    address: '192.168.0.134',
    location: 'country/India-Ahmedabad',
    status: 'online'
  },
  {
    id: 2,
    name: 'SECURUS',
    firmware: 'V1.00.T01.J2188953.10010.14',
    address: '192.168.0.175',
    location: 'country/Ahmedabad-India',
    status: 'online'
  },
  {
    id: 3,
    name: 'NVT',
    firmware: 'V1.00.T01.J2188953.10010.14',
    address: '192.168.0.173',
    location: 'country/china',
    status: 'online'
  },
  {
    id: 4,
    name: 'NVT',
    firmware: 'V5.00.R02.J2174907.00010.14',
    address: '192.168.0.87',
    location: 'country/china',
    status: 'offline'
  },
  {
    id: 5,
    name: 'SECURUS',
    firmware: 'V5.00.R02.844699N5.10010.14',
    address: '192.168.0.172',
    location: 'country/Ahmedabad-India',
    status: 'online'
  },
  {
    id: 6,
    name: 'SECURUS',
    firmware: 'V1.00.T01.J2188953.10010.14',
    address: '192.168.0.171',
    location: 'country/Ahmedabad-India',
    status: 'offline'
  }
];

const DeviceList = ({ selectedDevice, setSelectedDevice, searchTerm, setSearchTerm }) => {
  const filteredDevices = mockDevices.filter(device =>
    device.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    device.address.includes(searchTerm) ||
    device.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="w-80 bg-gray-50 border-r border-gray-200 flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-800">Device list</h2>
        <div className="mt-2 flex space-x-2">
          <input
            type="text"
            placeholder="Name, location or address"
            className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button className="px-3 py-2 bg-gray-200 text-gray-700 rounded-md text-sm hover:bg-gray-300">
            Cancel
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {filteredDevices.map(device => (
          <DeviceCard
            key={device.id}
            device={device}
            isSelected={selectedDevice?.id === device.id}
            onClick={() => setSelectedDevice(device)}
          />
        ))}
      </div>
      
      <div className="p-3 border-t border-gray-200 bg-white flex justify-between items-center">
        <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">
          NVT
        </button>
        <button className="p-1 text-gray-500 hover:text-gray-700">
          <ArrowPathIcon className="h-5 w-5" />
        </button>
        {/* <select className="px-2 py-1 border border-gray-300 rounded text-sm">
          <option>000: Profile_000</option>
        </select> */}
      </div>
    </div>
  );
};

export default DeviceList;