import React from 'react';

const DeviceCard = ({ device, isSelected, onClick }) => {
  return (
    <div
      className={`p-3 border-b border-gray-200 cursor-pointer ${isSelected ? 'bg-blue-50' : 'bg-white'} hover:bg-gray-50`}
      onClick={onClick}
    >
      <div className="flex justify-between items-start">
        <h3 className="font-medium text-gray-900">{device.name}</h3>
        <span className={`inline-block h-2 w-2 rounded-full ${device.status === 'online' ? 'bg-green-500' : 'bg-red-500'}`}></span>
      </div>
      <p className="text-xs text-gray-500 mt-1">Firmware {device.firmware}</p>
      <p className="text-xs text-gray-500">Address: {device.address}</p>
      <p className="text-xs text-gray-500">Location: {device.location}</p>
    </div>
  );
};

export default DeviceCard;