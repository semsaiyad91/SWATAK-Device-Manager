import React from 'react';
import { ArrowUpIcon, ArrowLeftIcon, ArrowRightIcon, ArrowDownIcon, PlusIcon, MinusIcon } from '@heroicons/react/24/outline';

const PTZControls = () => {
  return (
    <div className="mt-4 bg-gray-50 p-4 rounded-lg">
      <h3 className="text-sm font-medium text-gray-700 mb-3">PTZ Controls</h3>
      <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto">
        <div></div>
        <button className="p-2 bg-white rounded-md shadow-sm hover:bg-gray-100 flex justify-center">
          <ArrowUpIcon className="h-5 w-5 text-gray-600" />
        </button>
        <div></div>
        
        <button className="p-2 bg-white rounded-md shadow-sm hover:bg-gray-100 flex justify-center">
          <ArrowLeftIcon className="h-5 w-5 text-gray-600" />
        </button>
        <div className="p-2 flex justify-center items-center text-xs text-gray-500">Center</div>
        <button className="p-2 bg-white rounded-md shadow-sm hover:bg-gray-100 flex justify-center">
          <ArrowRightIcon className="h-5 w-5 text-gray-600" />
        </button>
        
        <div></div>
        <button className="p-2 bg-white rounded-md shadow-sm hover:bg-gray-100 flex justify-center">
          <ArrowDownIcon className="h-5 w-5 text-gray-600" />
        </button>
        <div></div>
        
        <button className="p-2 bg-white rounded-md shadow-sm hover:bg-gray-100 flex justify-center">
          <PlusIcon className="h-5 w-5 text-gray-600" />
        </button>
        <div className="p-2 flex justify-center items-center text-xs text-gray-500">Zoom</div>
        <button className="p-2 bg-white rounded-md shadow-sm hover:bg-gray-100 flex justify-center">
          <MinusIcon className="h-5 w-5 text-gray-600" />
        </button>
      </div>
    </div>
  );
};

export default PTZControls;